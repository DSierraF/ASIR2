<h1>Contactos</h1>
<a href="indice.html">Volver al indice</a>
<p>Para guardar presione el botón</p>
<form action="guardar.php" action="get" >
    Nombre: <input type="text" name="nomb"><br>
    Trabajo: <input type="text" name="tra"><br>
    Telefono: <input type="number" name="telf"><br>
    Direccion: <input type="text" name="dir"><br>
    Otras: <input type="text" name="otr"><br>
    <input type="submit" value="Guardar"><input type="reset" value="Reset">
</form>
<?php
?>