
<h1>Contactos</h1>
<a href="indice.html">Volver al indice</a><br><br>
<?php
print("Contacto guardado exitosamente");
if(trim($_REQUEST[nomb]) != ""){
 $fich= fopen("contactos.txt", "a");
 fputs($fich, trim($_REQUEST[nomb]) .":". trim($_REQUEST[tra]) ." ". trim($_REQUEST[telf]) ." ". trim($_REQUEST[dir]) ." ". trim($_REQUEST[otr]) . " " . PHP_EOL);
 fclose($fich);}
?>