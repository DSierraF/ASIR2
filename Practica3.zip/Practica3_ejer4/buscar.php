<h1>Contactos</h1>
<a href="indice.html">Volver al indice</a><br><br>
<form action="buscar1.php" action="get" >
    Contacto que desea buscar: <input type="text" name="nomb"><br>
    <input type="submit" name="Buscar" value="Buscar">
</form>