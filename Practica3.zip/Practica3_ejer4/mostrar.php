<?php
$fich= fopen("contactos.txt", "r");
while(!feof($fich)) {
 $linea = fgets($fich);
 echo $linea . "<br />";
}
fclose($fich);

?>