<h1>Contactos</h1>
<a href="indice.html">Volver al indice</a><br><br>
<?php
$fich = "contactos.txt";
$fd = fopen($fich, "r");
$linea = fgets($fich);

if(isset($_REQUEST[Buscar])){
    while( (($linea = fgets($fd)) !== false)){
        $array = explode(":", $linea);
        $texto = $_REQUEST[nomb];
        $codigo = $array[0];
        
        if((trim($texto) == trim($codigo)) ){
            echo"Contacto: $codigo $array[1] <br>";
        }
    }

}
fclose($fich);