<?php
print"<h1>Jugador 1</h1>";
$contador1=0;
for ($i=0;$i<5;$i++){
    $dado1 = rand(1,6);
    print "<img src='./img/$dado1.jpg'</p> \n";
    $contador1 = $contador1+$dado1;
    
   
}
print $contador1;

print"<br>";
$contador2=0;
print"<h1>Jugador 2</h1>";
for ($i=0;$i<5;$i++){
    $dado2 = rand(1,6);
    
    print "<img src='./img/$dado2.jpg'</p> \n";
    $contador2 = $contador2 +$dado2;
    
   
}
print $contador2;

if( $contador2 > $contador1){
    print "<h1>Resultado:</h1>";
    print "<p>El ganador es el Jugador <b>2</b>, con una puntuacion de ". $contador2 ." puntos.</p>";
}else{
    if( $contador1 > $contador2){
        print "<h1>Resultado:</h1>";
        print "<p>El ganador es el Jugador <b>1</b>, con una puntuacion de ". $contador1 ." puntos.</p>";
    }else{
        if($contador2 = $contador1){
            print "<h1>Resultado:</h1>";
            print "Los contadorugadores han empatado, con una puntuacion de ". $contador2 ." puntos.";
        }
    }
}


?>
