<style>
    td{
        padding: 6px;
    }
</style>
<form action="datos_alumno.php" method="get">
    <table style='border: solid black'>
        <tr>
            <td>DATOS DEL ALUMNO:</td>
            <td></td>
            <td></td>
            <td></td>
        </tr>
        <tr>
            <td>Introduzca su nombre:</td>
            <td><input type='text' name='nomb'></td>
            <td colspan='2' style='text-align: center'>Enseñanza</td>
        </tr>

        <tr>
            <td>Introduzca su telefono:</td>
            <td><input type='number' name='telf' size='7'> Matriculado<input type='checkbox' value="si" name='mat'></td>
            <td>Secundaria<input type='radio' value='Secundaria' required name='ens'></td>
            <td>Bachillerato<input class='check' type='radio' value='Bachillerato' name='ens'></td>
        </tr>
        <tr>
            <td>Mostrar datos:</td>
            <td>
                <select name='dat'>
                    <option value='txt'>En archivo .txt</option>
                    <option value='pant'>Por pantalla</option>
                </select>
            </td>
            <td>Ciclo medio<input type='radio' value='un Ciclo medio' name='ens'></td>
            <td>Ciclo superior<input type='radio' value='un Ciclo superior' name='ens'></td>
        </tr>
    </table><br>
    <input type="submit" value="Enviar">
</form>
<?php






?>